<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application. Just store away!
    |
    */

    'default' => env('FILESYSTEM_DISK', 'local'),

    'protected' => env('PROTECTED_FILESYSTEM_DISK', 'local_protected'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Here you may configure as many filesystem "disks" as you wish, and you
    | may even configure multiple disks of the same driver. Defaults have
    | been set up for each driver as an example of the required values.
    |
    | Supported Drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => public_path('uploads'),
            'url' => env('APP_URL').'/uploads',
            'throw' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => public_path('uploads'),
            'url' => env('APP_URL').'/uploads',
            'visibility' => 'public',
            'throw' => false,
        ],

        'local_protected' => [
            'driver' => 'local',
            'root' => public_path('uploads'),
            'url' => env('APP_URL').'/uploads',
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
            'visibility' => 'public',
            'use_path_style_endpoint' => env('AWS_USE_PATH_STYLE_ENDPOINT', false),
            'throw' => false,
        ],

        's3_protected' => [
            'driver' => 's3',
            'key' => env('PRO_AWS_ACCESS_KEY_ID'),
            'secret' => env('PRO_AWS_SECRET_ACCESS_KEY'),
            'region' => env('PRO_AWS_DEFAULT_REGION'),
            'bucket' => env('PRO_AWS_BUCKET'),
            'url' => env('PRO_AWS_URL'),
            'endpoint' => env('PRO_AWS_ENDPOINT'),
        ],

        's3_temp' => [
            'driver' => 's3',
            'key' => env('TEMP_AWS_ACCESS_KEY_ID'),
            'secret' => env('TEMP_AWS_SECRET_ACCESS_KEY'),
            'region' => env('TEMP_AWS_DEFAULT_REGION'),
            'bucket' => env('TEMP_AWS_BUCKET'),
            'url' => env('TEMP_AWS_URL'),
            'endpoint' => env('TEMP_AWS_ENDPOINT'),
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
